<?php

namespace App\Interface;

use App\Entity\Abstract\AbstractJoueur;

interface AtoutInterface
{
    public function atout() : array;
}